title: 在阿里云上部署 solo 博客
date: '2019-04-24 01:54:09'
updated: '2019-04-24 02:00:01'
tags: [CentOS, docker, Solo]
permalink: /articles/2019/04/24/1556042049609.html
---
[Solo](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fb3log%2Fsolo) 是一款小而美的开源博客系统，专为程序员设计。Solo 有着非常活跃的[社区](https://hacpai.com/)，文章自动推送到社区后可以让很多人看到，产生丰富的交流互动。
### Docker 部署

获取最新镜像：

`docker pull b3log/solo `

*   使用 MySQL
    
    先手动建库（库名 `solo`，字符集使用 `utf8mb4`，排序规则 `utf8mb4_general_ci`），然后启动容器：
	docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=hassis.club

启动参数说明：

*   `--listen_port`：进程监听端口
*   `--server_scheme`：最终访问协议，如果反代服务启用了 HTTPS 这里也需要改为 `https`
*   `--server_host`：最终访问域名或公网 IP，不要带端口号

完整启动参数的说明可以使用 `-h` 来查看。

 